import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class FriendsBookApp {
    private JFrame frame;
    private DefaultListModel<Friend> friendListModel;
    private JList<Friend> friendJList;
    private ArrayList<Friend> friends;

    public FriendsBookApp() {
        friends = new ArrayList<>();
        friendListModel = new DefaultListModel<>();

        frame = new JFrame("Friends Book");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        friendJList = new JList<>(friendListModel);
        frame.add(new JScrollPane(friendJList), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Friend");
        JButton viewButton = new JButton("View Friend");
        JButton deleteButton = new JButton("Delete Friend");

        buttonPanel.add(addButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(deleteButton);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        addButton.addActionListener(e -> addFriend());
        viewButton.addActionListener(e -> viewFriend());
        deleteButton.addActionListener(e -> deleteFriend());

        frame.setVisible(true);
    }

    private void addFriend() {
        JTextField nameField = new JTextField();
        JTextField ageField = new JTextField();
        JTextField contactField = new JTextField();

        Object[] fields = {
                "Name:", nameField,
                "Age:", ageField,
                "Contact:", contactField
        };

        int option = JOptionPane.showConfirmDialog(frame, fields, "Add Friend", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                String name = nameField.getText().trim();
                int age = Integer.parseInt(ageField.getText().trim());
                String contact = contactField.getText().trim();

                if (name.isEmpty() || contact.isEmpty() || age < 0) {
                    JOptionPane.showMessageDialog(frame, "Invalid input!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Friend newFriend = new Friend(name, age, contact);
                friends.add(newFriend);
                friendListModel.addElement(newFriend);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(frame, "Age must be a number!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void viewFriend() {
        Friend selectedFriend = friendJList.getSelectedValue();
        if (selectedFriend != null) {
            JOptionPane.showMessageDialog(frame,
                    "Name: " + selectedFriend.getName() + "\n" +
                            "Age: " + selectedFriend.getAge() + "\n" +
                            "Contact: " + selectedFriend.getContact(),
                    "Friend Details", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(frame, "Select a friend to view details.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteFriend() {
        Friend selectedFriend = friendJList.getSelectedValue();
        if (selectedFriend != null) {
            friends.remove(selectedFriend);
            friendListModel.removeElement(selectedFriend);
        } else {
            JOptionPane.showMessageDialog(frame, "Select a friend to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(FriendsBookApp::new);
    }
}
