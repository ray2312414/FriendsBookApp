public class Friend {
    private String name;
    private int age;
    private String contact;

    // Constructor
    // requires: name (non-empty), age (>= 0), contact (non-empty)
    // modifies: this
    // effects: initializes a Friend object with the given name, age, and contact
    public Friend(String name, int age, String contact) {
        this.name = name;
        this.age = age;
        this.contact = contact;
    }

    // Getter for name
    // requires: nothing
    // modifies: nothing
    // effects: returns the friend's name
    public String getName() {
        return name;
    }

    // Getter for age
    // requires: nothing
    // modifies: nothing
    // effects: returns the friend's age
    public int getAge() {
        return age;
    }

    // Getter for contact
    // requires: nothing
    // modifies: nothing
    // effects: returns the friend's contact info
    public String getContact() {
        return contact;
    }

    // toString method for displaying friend info in the GUI list
    // requires: nothing
    // modifies: nothing
    // effects: returns a string representation of the friend
    @Override
    public String toString() {
        return name + " (Age: " + age + ")";
    }
}
